#ifndef WAREHOUSE_H
#define WAREHOUSE_H

#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

// =================== GLOBAL LOG ===================
extern ofstream logFile;

// =================== PRODUCT (BST) ===================
struct Product {
    int id;
    char name[50];
    int qty;
    int shelf;
    int freq;  
    Product *left, *right;

    Product(int i=0, const char* n="", int q=0, int s=0);
};

extern Product* proot;
extern int warehouseStock;

// BST Functions
Product* insertProduct(Product* r, int id, const char* name, int qty, int shelf);
Product* searchProduct(Product* r, int id);
void displayProducts(Product* r);
void prefixSearch(Product* r, const char* prefix);
Product* deleteProduct(Product* r, int id);

// =================== UNDO STACK ===================
struct UndoNode {
    int id, qty;
    UndoNode* next;
    UndoNode(int i,int q);
};
extern UndoNode* undoTop;

void recordUndo(int id,int qty);
void undoProductAction();

// =================== PICKERS ===================
struct Picker {
    int id;
    char name[30];
    bool busy;
    int pendingOrders;
    Picker* next;
    Picker(int i,const char* n);
};
extern Picker* plist;

void addPicker(int id,const char* name);
Picker* getLeastLoadedPicker();
void completePickerTasks();

// =================== MAX HEAP (Orders) ===================
struct Order {
    int oid, pid, qty, priority;
    char customerName[50];
    char customerContact[50];
    bool completed;
};

extern Order* heapArr[100];
extern int heapSize;

void swapOrder(Order* &a, Order* &b);
void heapifyUp(int i);
void heapifyDown(int i);
void heapInsert(Order* o);
Order* heapRemoveMax();

// =================== ORDER UNDO STACK ===================
struct OrderUndo {
    int pid, qtyUndo;
    OrderUndo* next;
    OrderUndo(int p,int q);
};
extern OrderUndo* orderUndoTop;

void recordOrderUndo(int pid,int qty);
void showOrderUndoList();
void undoOrderAction();

// =================== GRAPH (Hard-coded) ===================
extern int graph[10][10];
extern int shelves;
void initGraph();
void showGraph();

// =================== FILE HANDLING ===================
void saveProducts(Product* r, ofstream &f);
void loadProducts();
void saveAll();

// =================== PROCESS ORDER ===================
void processOrder();

#endif