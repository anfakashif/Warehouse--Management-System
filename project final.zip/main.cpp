#include "warehouse.h"

int main() {
    logFile.open("output.txt", ios::app);
    initGraph();
    loadProducts();

    // Add pickers
    addPicker(1, "Ali");
    addPicker(2, "Sara");
    addPicker(3, "Nadia");

    int ch;
    while(true) {
        cout << "\n=== SIMPLE WAREHOUSE SYSTEM ===\n";
        cout << "1. Add Product\n2. Edit Product\n3. Delete Product\n4. Search Product\n5. Prefix Search\n";
        cout << "6. Add Order\n7. Process Order\n8. Show Graph\n";
        cout << "9. Undo Product Action\n10. Undo Order Action\n11. Show Products\n0. Exit\n";
        cout << "Enter: "; 
        cin >> ch;
        if(ch == 0) break;

        if(ch == 1) {
            int id, qty, shelf; 
            char name[50];
            cout << "ID Name Qty Shelf: "; 
            cin >> id >> name >> qty >> shelf;
            Product* p = searchProduct(proot, id);
            if(p) { 
                p->qty += qty; 
                cout << "Quantity added.\n"; 
            }
            else { 
                proot = insertProduct(proot, id, name, qty, shelf); 
                cout << "Product added.\n"; 
            }
            recordUndo(id, qty); 
            warehouseStock -= qty;
        }
        else if(ch == 2) {
            int id; 
            cout << "ID: "; 
            cin >> id;
            Product* p = searchProduct(proot, id);
            if(!p) { 
                cout << "Not found.\n"; 
                continue; 
            }
            cout << "New name new qty new shelf: "; 
            cin >> p->name >> p->qty >> p->shelf;
        }
        else if(ch == 3) {
            int id; 
            cout << "ID to delete: "; 
            cin >> id;
            proot = deleteProduct(proot, id); 
            cout << "Product deleted.\n";
        }
        else if(ch == 4) {
            int id; 
            cout << "ID: "; 
            cin >> id;
            Product* p = searchProduct(proot, id);
            if(p) cout << "Found: " << p->name << " Qty " << p->qty << endl;
            else cout << "Not found.\n";
        }
        else if(ch == 5) {
            char prefix[50]; 
            cout << "Prefix: "; 
            cin >> prefix;
            prefixSearch(proot, prefix);
        }
        else if(ch == 6) {
            cout << "\n--- Available Products ---\n";
            if(!proot) cout << "No products available!\n";
            else displayProducts(proot);
            cout << "--------------------------\n";

            int n; 
            cout << "How many orders to add? "; 
            cin >> n;
            for(int i = 0; i < n; i++) {
                int oid, pid, qty, pr;
                char cname[50], ccontact[50];
                cout << "Order " << i+1 << " (OID PID Qty Priority CustomerName CustomerContact): ";
                cin >> oid >> pid >> qty >> pr >> cname >> ccontact;

                Product* p = searchProduct(proot, pid);
                if(!p) { 
                    cout << "Product ID " << pid << " does NOT exist.\n"; 
                    continue; 
                }
                if(qty > p->qty) { 
                    cout << "Not enough stock! Available: " << p->qty << "\n"; 
                    continue; 
                }

                Order* o = new Order();
                o->oid = oid; 
                o->pid = pid; 
                o->qty = qty; 
                o->priority = pr;
                strcpy(o->customerName, cname); 
                strcpy(o->customerContact, ccontact);
                o->completed = false;

                heapInsert(o);
                cout << " Order added successfully.\n";
            }
        }
        else if(ch == 7) processOrder();
        else if(ch == 8) showGraph();
        else if(ch == 9) undoProductAction();
        else if(ch == 10) undoOrderAction();
        else if(ch == 11) displayProducts(proot);

        completePickerTasks();
    }

    saveAll(); 
    logFile.close();
    return 0;
}