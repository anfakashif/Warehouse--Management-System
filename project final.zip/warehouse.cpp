#include "warehouse.h"

// =================== GLOBAL VARIABLES ===================
ofstream logFile;
Product* proot = NULL;
int warehouseStock = 1000;
UndoNode* undoTop = NULL;
Picker* plist = NULL;
Order* heapArr[100];
int heapSize = 0;
OrderUndo* orderUndoTop = NULL;
int graph[10][10];
int shelves = 8;

// =================== PRODUCT IMPLEMENTATION ===================
Product::Product(int i, const char* n, int q, int s) {
    id = i; 
    strcpy(name, n); 
    qty = q; 
    shelf = s; 
    freq = 0;
    left = right = NULL;
}

Product* insertProduct(Product* r, int id, const char* name, int qty, int shelf) {
    if(!r) return new Product(id, name, qty, shelf);
    if(id < r->id) r->left = insertProduct(r->left, id, name, qty, shelf);
    else if(id > r->id) r->right = insertProduct(r->right, id, name, qty, shelf);
    else r->qty += qty;
    return r;
}

Product* searchProduct(Product* r, int id) {
    if(!r) return NULL;
    if(id == r->id) return r;
    if(id < r->id) return searchProduct(r->left, id);
    return searchProduct(r->right, id);
}

void displayProducts(Product* r) {
    if(!r) return;
    displayProducts(r->left);
    cout << r->id << " | " << r->name << " | Qty: " << r->qty 
         << " | Shelf " << r->shelf << " | Freq " << r->freq << endl;
    displayProducts(r->right);
}

void prefixSearch(Product* r, const char* prefix) {
    if(!r) return;
    prefixSearch(r->left, prefix);
    if(strncmp(r->name, prefix, strlen(prefix)) == 0)
        cout << r->id << " | " << r->name << " | Qty: " << r->qty 
             << " | Freq " << r->freq << endl;
    prefixSearch(r->right, prefix);
}

Product* deleteProduct(Product* r, int id) {
    if(!r) return NULL;
    if(id < r->id) r->left = deleteProduct(r->left, id);
    else if(id > r->id) r->right = deleteProduct(r->right, id);
    else {
        if(!r->left) { 
            Product* tmp = r->right; 
            delete r; 
            return tmp; 
        }
        else if(!r->right) { 
            Product* tmp = r->left; 
            delete r; 
            return tmp; 
        }
        else {
            Product* succ = r->right;
            while(succ->left) succ = succ->left;
            r->id = succ->id;
            strcpy(r->name, succ->name);
            r->qty = succ->qty;
            r->shelf = succ->shelf;
            r->freq = succ->freq;
            r->right = deleteProduct(r->right, succ->id);
        }
    }
    return r;
}

// =================== UNDO STACK IMPLEMENTATION ===================
UndoNode::UndoNode(int i, int q) {
    id = i; 
    qty = q; 
    next = NULL;
}

void recordUndo(int id, int qty) {
    UndoNode* u = new UndoNode(id, qty);
    u->next = undoTop;
    undoTop = u;
}

void undoProductAction() {
    if(!undoTop) { 
        cout << "No product actions to undo.\n"; 
        return; 
    }
    UndoNode* u = undoTop;
    undoTop = undoTop->next;

    Product* p = searchProduct(proot, u->id);
    if(p) {
        int undoQty = u->qty;
        if(undoQty > p->qty) undoQty = p->qty;
        p->qty -= undoQty;
        warehouseStock += undoQty;
        cout << "Undo: Returned " << undoQty << " units of " << p->name << endl;
        logFile << "Undo: Returned " << undoQty << " units of " << p->name << endl;
    }
    delete u;
}

// =================== PICKERS IMPLEMENTATION ===================
Picker::Picker(int i, const char* n) {
    id = i; 
    strcpy(name, n); 
    busy = false; 
    pendingOrders = 0; 
    next = NULL;
}

void addPicker(int id, const char* name) {
    Picker* p = new Picker(id, name);
    p->next = plist;
    plist = p;
}

Picker* getLeastLoadedPicker() {
    Picker* best = NULL;
    for(Picker* p = plist; p; p = p->next) {
        if(!p->busy) {
            if(!best || p->pendingOrders < best->pendingOrders)
                best = p;
        }
    }
    return best;
}

void completePickerTasks() {
    for(Picker* p = plist; p; p = p->next) {
        if(p->pendingOrders > 0) {
            p->pendingOrders--;
            if(p->pendingOrders == 0) p->busy = false;
        }
    }
}

// =================== MAX HEAP IMPLEMENTATION ===================
void swapOrder(Order* &a, Order* &b) { 
    Order* t = a; 
    a = b; 
    b = t; 
}

void heapifyUp(int i) {
    while(i > 1) {
        int parent = i / 2;
        if(heapArr[i]->priority > heapArr[parent]->priority) {
            swapOrder(heapArr[i], heapArr[parent]);
            i = parent;
        } else break;
    }
}

void heapifyDown(int i) {
    while(true) {
        int left = i * 2, right = i * 2 + 1, largest = i;
        if(left <= heapSize && heapArr[left]->priority > heapArr[largest]->priority) 
            largest = left;
        if(right <= heapSize && heapArr[right]->priority > heapArr[largest]->priority) 
            largest = right;
        if(largest != i) { 
            swapOrder(heapArr[i], heapArr[largest]); 
            i = largest; 
        } else break;
    }
}

void heapInsert(Order* o) {
    heapSize++;
    heapArr[heapSize] = o;
    heapifyUp(heapSize);
}

Order* heapRemoveMax() {
    if(heapSize == 0) return NULL;
    Order* top = heapArr[1];
    heapArr[1] = heapArr[heapSize];
    heapSize--;
    heapifyDown(1);
    return top;
}

// =================== ORDER UNDO STACK IMPLEMENTATION ===================
OrderUndo::OrderUndo(int p, int q) {
    pid = p; 
    qtyUndo = q; 
    next = NULL;
}

void recordOrderUndo(int pid, int qty) {
    OrderUndo* u = new OrderUndo(pid, qty);
    u->next = orderUndoTop;
    orderUndoTop = u;
}

void showOrderUndoList() {
    if(!orderUndoTop) { 
        cout << "No order actions to undo.\n"; 
        return; 
    }
    cout << "\n=== Undoable Orders ===\n";
    OrderUndo* temp = orderUndoTop;
    int i = 1;
    while(temp) {
        Product* p = searchProduct(proot, temp->pid);
        if(p) cout << i << ". Product: " << p->name << " | Undo Qty Available: " << temp->qtyUndo << endl;
        temp = temp->next; 
        i++;
    }
}

void undoOrderAction() {
    if(!orderUndoTop) { 
        cout << "No order actions to undo.\n"; 
        return; 
    }
    showOrderUndoList();

    int choice, qtyAsk;
    cout << "\nSelect action number to undo: "; 
    cin >> choice;

    OrderUndo* temp = orderUndoTop;
    OrderUndo* prev = NULL; 
    int index = 1;
    while(temp && index < choice) { 
        prev = temp; 
        temp = temp->next; 
        index++; 
    }
    if(!temp) { 
        cout << "Invalid choice.\n"; 
        return; 
    }

    Product* p = searchProduct(proot, temp->pid);
    if(!p) { 
        cout << "Product not found.\n"; 
        return; 
    }

    cout << "Enter quantity to undo (Available: " << temp->qtyUndo << "): ";
    cin >> qtyAsk;
    if(qtyAsk <= 0 || qtyAsk > temp->qtyUndo) { 
        cout << "Invalid quantity.\n"; 
        return; 
    }

    p->qty += qtyAsk;
    warehouseStock -= qtyAsk;
    cout << qtyAsk << " units restored to product " << p->name << endl;

    temp->qtyUndo -= qtyAsk;
    if(temp->qtyUndo == 0) {
        if(prev == NULL) orderUndoTop = temp->next;
        else prev->next = temp->next;
        delete temp;
    }
}

// =================== GRAPH IMPLEMENTATION ===================
void initGraph() {
    for(int i = 0; i < 10; i++) 
        for(int j = 0; j < 10; j++) 
            graph[i][j] = 0;
    
    graph[0][1] = graph[1][0] = 1;
    graph[1][2] = graph[2][1] = 1;
    graph[2][3] = graph[3][2] = 1;
    graph[3][4] = graph[4][3] = 1;
    graph[4][5] = graph[5][4] = 1;
    graph[5][6] = graph[6][5] = 1;
    graph[6][7] = graph[7][6] = 1;
    graph[0][5] = graph[5][0] = 1;
    graph[2][6] = graph[6][2] = 1;
}

void showGraph() {
    cout << "\nWarehouse Graph:\n";
    for(int i = 0; i < shelves; i++) {
        cout << "Shelf " << i << ": ";
        for(int j = 0; j < shelves; j++) 
            if(graph[i][j] == 1) cout << j << " ";
        cout << endl;
    }
}

// =================== FILE HANDLING IMPLEMENTATION ===================
void saveProducts(Product* r, ofstream &f) {
    if(!r) return;
    saveProducts(r->left, f);
    f << r->id << " " << r->name << " " << r->qty << " " << r->shelf << "\n";
    saveProducts(r->right, f);
}

void loadProducts() {
    ifstream f("products.txt");
    if(!f) return;
    int id, qty, shelf; 
    char name[50];
    while(f >> id >> name >> qty >> shelf) 
        proot = insertProduct(proot, id, name, qty, shelf);
    f.close();
}

void saveAll() {
    ofstream fp("products.txt");
    saveProducts(proot, fp);
    fp.close();
}

// =================== PROCESS ORDER IMPLEMENTATION ===================
void processOrder() {
    Order* o = heapRemoveMax();
    if(!o) { 
        cout << "No orders.\n"; 
        return; 
    }

    Product* p = searchProduct(proot, o->pid);
    if(!p) { 
        cout << "Product not found.\n"; 
        delete o; 
        return; 
    }

    if(p->qty < o->qty) { 
        cout << "Insufficient stock.\n"; 
        delete o; 
        return; 
    }

    p->qty -= o->qty;
    p->freq += o->qty;
    recordOrderUndo(p->id, o->qty);

    Picker* pk = getLeastLoadedPicker();
    if(pk) {
        cout << "Assigned picker: " << pk->name << " (Pending orders: " << pk->pendingOrders << ")" << endl;
        pk->pendingOrders++; 
        pk->busy = true;
    } else cout << "All pickers busy, order will wait.\n";

    cout << "\n=== ORDER MANIFEST ===\n";
    cout << "Customer: " << o->customerName << " | Contact: " << o->customerContact << endl;
    cout << "Product: " << p->name << " | Qty: " << o->qty << " | Shelf: " << p->shelf << endl;
    cout << "Estimated Time: " << o->qty << " units\n";
    cout << "-----------------------\n";

    o->completed = true;
    logFile << "Processed Order " << o->oid << " for " << o->customerName << endl;
    delete o;
}